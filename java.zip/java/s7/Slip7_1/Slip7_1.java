import Series.*;
public class Slip7_1
{
	public static void main(String args[])
	{
		System.out.println("Prime number series 1-50:");
        Prime.primeseries(50);
		System.out.println("\n Squares number series(1-10) :");
		Squares.squareseries(10);
	}
}