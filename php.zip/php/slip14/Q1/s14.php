<?PHP
if($_POST['b1'])
{
$n=$_POST['t1'];
$marks=array(100,50,56,78,66,76,99,98);
echo "contents of array is<br>";
  print_r($marks);
if(in_array($n,$marks))
	echo"The searched element is $n";
else
	echo"The searched element does not found in array";
}
?>
